import socket
from typing import Tuple, Optional
from .base import Protocol


class TCPProtocol(Protocol):
   def __init__(self):
       self.socket = None
       self.client_socket = None
       self.is_server = False

   def initialize(self) -> bool:
       try:
           self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
           self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
           return True
       except Exception as e:
           print(f"TCP initialization error: {e}")
           return False

   def listen(self, host: str, port: int) -> bool:
       if not self.socket:
           return False

       self.is_server = True
       try:
           self.socket.bind((host, port))
           self.socket.listen(5)
           print(f"TCP server listening on {host}:{port}")
           return True
       except Exception as e:
           print(f"TCP listen error: {e}")
           return False

   def accept(self) -> Tuple[bool, Optional[str]]:
       if not self.is_server or not self.socket:
           return False, None

       try:
           self.client_socket, addr = self.socket.accept()
           client_addr = f"{addr[0]}:{addr[1]}"
           print(f"TCP client connected: {client_addr}")
           return True, client_addr
       except Exception as e:
           print(f"TCP accept error: {e}")
           return False, None

   def connect(self, host: str, port: int) -> bool:
       if not self.socket:
           return False

       try:
           self.socket.connect((host, port))
           print(f"TCP connected to server: {host}:{port}")
           return True
       except Exception as e:
           print(f"TCP connect error: {e}")
           return False

   def send(self, data: bytes) -> int:
       sock = self.client_socket if self.is_server else self.socket
       if not sock:
           return 0

       try:
           return sock.send(data)
       except Exception as e:
           print(f"TCP send error: {e}")
           return 0

   def receive(self, max_size: int = 65535) -> bytes:
       sock = self.client_socket if self.is_server else self.socket
       if not sock:
           return b''

       try:
           return sock.recv(max_size)
       except Exception as e:
           print(f"TCP receive error: {e}")
           return b''

   def close(self) -> None:
       if self.client_socket:
           try:
               self.client_socket.close()
           except:
               pass
           self.client_socket = None

       if self.socket:
           try:
               self.socket.close()
           except:
               pass
           self.socket = None

   @property
   def name(self) -> str:
       return "TCP"