from abc import ABC, abstractmethod
from typing import List, Tuple, Optional


class Protocol(ABC):
    """Base protocol interface for all transport protocols."""

    @abstractmethod
    def initialize(self) -> bool:
        """Initialize the protocol."""
        pass

    @abstractmethod
    def listen(self, host: str, port: int) -> bool:
        """Start listening for connections (server-side)."""
        pass

    @abstractmethod
    def accept(self) -> Tuple[bool, Optional[str]]:
        """Accept incoming connection (server-side)."""
        pass

    @abstractmethod
    def connect(self, host: str, port: int) -> bool:
        """Connect to a server (client-side)."""
        pass

    @abstractmethod
    def send(self, data: bytes) -> int:
        """Send data over the connection."""
        pass

    @abstractmethod
    def receive(self, max_size: int = 65535) -> bytes:
        """Receive data from the connection."""
        pass

    @abstractmethod
    def close(self) -> None:
        """Close the connection."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the protocol name."""
        pass