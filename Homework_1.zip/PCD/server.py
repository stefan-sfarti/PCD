import argparse
import time
import os
from typing import Dict, Any, List
import json

from protocol.tcp_protocol import TCPProtocol
from protocol.udp_protocol import UDPProtocol


def create_protocol(protocol_name: str):
    """Create protocol handler based on name."""
    if protocol_name.upper() == "TCP":
        return TCPProtocol()
    elif protocol_name.upper() == "UDP":
        return UDPProtocol()
    else:
        raise ValueError(f"Unsupported protocol: {protocol_name}")


def run_server(host: str, port: int, protocol_name: str, is_streaming: bool = False) -> Dict[str, Any]:
    """Run server to receive data and measure performance."""
    # Create and initialize protocol
    protocol = create_protocol(protocol_name)
    if not protocol.initialize() or not protocol.listen(host, port):
        return {"error": "Failed to initialize server"}

    # Wait for client connection
    success, client_addr = protocol.accept()
    if not success:
        protocol.close()
        return {"error": "Failed to accept client connection"}

    print(f"Client connected from {client_addr}, receiving data...")

    # Receive and measure data
    total_received = 0
    total_messages = 0
    start_time = time.time()

    while True:
        data = protocol.receive(65535)
        if not data:
            if protocol_name.upper() == "UDP":
                continue
            else:
                break

        # Check for termination message
        if data == b'DONE':
            break

        # Only send acknowledgments for stop-and-wait transfers
        if not is_streaming and len(data) >= 4:
            message_id = data[:4]
            ack = b'ACK' + message_id
            protocol.send(ack)

        total_received += len(data)
        total_messages += 1

        # Print progress occasionally
        if total_messages % 1000 == 0:
            elapsed = time.time() - start_time
            mbps = (total_received * 8 / 1_000_000) / elapsed if elapsed > 0 else 0
            print(f"Received: {total_received / 1_000_000:.2f} MB, Messages: {total_messages}, "
                  f"Throughput: {mbps:.2f} Mbps")

    end_time = time.time()
    duration = end_time - start_time

    # Calculate metrics
    throughput_mbps = (total_received * 8 / 1_000_000) / duration if duration > 0 else 0

    # Close connection
    protocol.close()

    # Prepare results
    results = {
        'protocol': protocol_name,
        'total_received': total_received,
        'total_messages': total_messages,
        'duration_sec': duration,
        'throughput_mbps': throughput_mbps
    }

    # Print summary
    print("\n===== Transfer Summary =====")
    print(f"Protocol: {protocol_name}")
    print(f"Total data received: {total_received:,} bytes ({total_received / 1_048_576:.2f} MB)")
    print(f"Total messages: {total_messages:,}")
    print(f"Duration: {duration:.2f} seconds")
    print(f"Throughput: {throughput_mbps:.2f} Mbps")

    return results


def main():
    parser = argparse.ArgumentParser(description="Network Benchmark Server")
    parser.add_argument("--host", default="0.0.0.0", help="Listening host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=5555, help="Listening port (default: 5555)")
    parser.add_argument("--protocol", default="TCP", choices=["TCP", "UDP"],
                        help="Transport protocol (default: TCP)")
    parser.add_argument("--is_streaming", default="True", choices=["True", "False"],
                        help="Streaming or Stop and Wait (default: True)")

    args = parser.parse_args()

    print(f"Starting {args.protocol} server on {args.host}:{args.port}")
    results = run_server(args.host, args.port, args.protocol)

    # Save results
    if "error" not in results:
        os.makedirs("results", exist_ok=True)
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"results/server_{args.protocol}_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {filename}")


if __name__ == "__main__":
    main()