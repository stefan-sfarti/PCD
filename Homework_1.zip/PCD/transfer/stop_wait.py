from typing import Callable, Dict, Any
import time
from protocol.base import Protocol


def stop_and_wait_transfer(
            protocol: Protocol,
            data_size: int,
            message_size: int,
            data_generator: Callable[[int], bytes],
            timeout: float = 1.0,
            max_retries: int = 3,
            progress_callback: Callable[[int, int], None] = None,
    ) -> Dict[str, Any]:
        total_sent = 0
        total_messages = 0
        total_retries = 0
        start_time = time.time()
        message_id = 0

        while total_sent < data_size:
            current_message_size = min(message_size, data_size - total_sent)

            message_data = data_generator(current_message_size - 4)  # Leave room for message ID
            message = message_id.to_bytes(4, byteorder='big') + message_data

            retries = 0
            ack_received = False

            while not ack_received and retries < max_retries:

                sent = protocol.send(message)

                if sent == 0:
                    retries += 1
                    total_retries += 1
                    time.sleep(0.01)
                    continue


                try:

                    if hasattr(protocol, 'receive') and timeout is not None and 'timeout' in protocol.receive.__code__.co_varnames:
                        ack = protocol.receive(1024, timeout=timeout)
                    else:

                        if hasattr(protocol, 'socket') and protocol.socket:
                            old_timeout = protocol.socket.gettimeout()
                            protocol.socket.settimeout(timeout)
                            try:
                                ack = protocol.receive(1024)
                            finally:
                                protocol.socket.settimeout(old_timeout)
                        else:
                            ack = protocol.receive(1024)

                    if ack and len(ack) >= 7 and ack.startswith(b'ACK') and ack[3:7] == message_id.to_bytes(4, byteorder='big'):
                        ack_received = True
                        total_sent += current_message_size
                        total_messages += 1
                        message_id = (message_id + 1) % 0xFFFFFFFF
                    else:
                        retries += 1
                        total_retries += 1
                        time.sleep(0.01)
                except Exception as e:
                    print(f"Error waiting for ACK: {e}")
                    retries += 1
                    total_retries += 1
                    time.sleep(0.01)

            if not ack_received:
                print(f"Failed to get acknowledgment after {max_retries} retries")
                break

            if progress_callback and total_messages % 10 == 0:
                progress_callback(total_sent, data_size)

        protocol.send(b'DONE')

        end_time = time.time()
        duration = end_time - start_time

        throughput_mbps = (total_sent * 8 / 1_000_000) / duration if duration > 0 else 0

        return {
            'protocol': protocol.name,
            'transfer_type': 'stop_and_wait',
            'data_size': data_size,
            'message_size': message_size,
            'total_sent': total_sent,
            'total_messages': total_messages,
            'total_retries': total_retries,
            'duration_sec': duration,
            'throughput_mbps': throughput_mbps
        }