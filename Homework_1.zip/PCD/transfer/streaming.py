from typing import Callable, Dict, Any
import time
from protocol.base import Protocol

def streaming_transfer(
        protocol: Protocol,
        data_size: int,
        message_size: int,
        data_generator: Callable[[int], bytes],
        progress_callback: Callable[[int, int], None] = None,
) -> Dict[str, Any]:
    """Perform streaming data transfer.

    Args:
        protocol: Protocol implementation to use
        data_size: Total amount of data to transfer in bytes
        message_size: Size of each message in bytes
        data_generator: Function to generate random data
        progress_callback: Function to call with progress updates

    Returns:
        Dictionary with benchmark results
    """
    total_sent = 0
    total_messages = 0
    start_time = time.time()

    while total_sent < data_size:
        # Adjust last message size if needed
        current_message_size = min(message_size, data_size - total_sent)

        # Generate and send message
        message = data_generator(current_message_size)
        sent = protocol.send(message)

        if sent == 0:
            # Send failed
            break

        total_sent += sent
        total_messages += 1

        # Report progress
        if progress_callback and total_messages % 100 == 0:
            progress_callback(total_sent, data_size)

    # Send termination message
    protocol.send(b'DONE')

    end_time = time.time()
    duration = end_time - start_time

    # Calculate metrics
    throughput_mbps = (total_sent * 8 / 1_000_000) / duration if duration > 0 else 0

    return {
        'protocol': protocol.name,
        'transfer_type': 'streaming',
        'data_size': data_size,
        'message_size': message_size,
        'total_sent': total_sent,
        'total_messages': total_messages,
        'duration_sec': duration,
        'throughput_mbps': throughput_mbps
    }