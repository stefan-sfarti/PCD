import socket
from typing import Tuple, Optional
from .base import Protocol


class UDPProtocol(Protocol):
    """UDP protocol implementation."""

    def __init__(self, buffer_size=8388608):  # 8MB buffer
        self.socket = None
        self.client_addr = None
        self.is_server = False
        self.server_addr = None
        self.buffer_size = buffer_size

    def initialize(self) -> bool:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, self.buffer_size)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, self.buffer_size)
            return True
        except Exception as e:
            print(f"UDP initialization error: {e}")
            return False

    def listen(self, host: str, port: int) -> bool:
        """Start listening for UDP datagrams."""
        if not self.socket:
            return False

        self.is_server = True
        try:
            self.socket.bind((host, port))
            print(f"UDP server listening on {host}:{port}")
            return True
        except Exception as e:
            print(f"UDP listen error: {e}")
            return False

    def accept(self) -> Tuple[bool, Optional[str]]:
        """In UDP, there's no formal connection to accept.
        We'll receive the first datagram to identify the client."""
        if not self.is_server or not self.socket:
            return False, None

        try:
            # Wait for the first datagram to identify the client
            data, addr = self.socket.recvfrom(1024)
            self.client_addr = addr
            client_str = f"{addr[0]}:{addr[1]}"
            print(f"UDP client identified: {client_str}")

            # Send an acknowledgment back
            self.socket.sendto(b'ACK', addr)

            return True, client_str
        except Exception as e:
            print(f"UDP accept error: {e}")
            return False, None

    def connect(self, host: str, port: int) -> bool:
        if not self.socket:
            return False

        try:
            self.server_addr = (host, port)
            self.socket.settimeout(5.0)

            try:
                data, _ = self.socket.recvfrom(1024)
            except socket.timeout:
                pass

            self.socket.settimeout(None)
            print(f"UDP endpoint configured for server: {host}:{port}")
            return True

        except Exception as e:
            print(f"UDP connect error: {e}")
            return False

    def send(self, data: bytes) -> int:
        if not self.socket:
            return 0

        try:
            if self.is_server and self.client_addr:
                return self.socket.sendto(data, self.client_addr)
            elif not self.is_server and self.server_addr:
                return self.socket.sendto(data, self.server_addr)
            return 0
        except Exception as e:
            print(f"UDP send error: {e}")
            return 0

    def receive(self, max_size: int = 65535, timeout: float = None) -> bytes:
                if not self.socket:
                    return b''

                try:
                    if timeout is not None and self.socket.gettimeout() != timeout:
                        self.socket.settimeout(timeout)

                    try:
                        data, addr = self.socket.recvfrom(max_size)
                        if self.is_server and (not self.client_addr or addr != self.client_addr):
                            self.client_addr = addr

                        return data
                    except socket.timeout:
                        return b''
                except Exception as e:
                    print(f"UDP receive error: {e}")
                    return b''

    def close(self) -> None:
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
            self.socket = None
            self.client_addr = None
            self.server_addr = None

    @property
    def name(self) -> str:
        return "UDP"