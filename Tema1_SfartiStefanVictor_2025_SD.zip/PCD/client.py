import argparse
import time
import os
import random
from typing import Dict, Any
import json

from protocol.tcp_protocol import TCPProtocol
from protocol.udp_protocol import UDPProtocol
from transfer.streaming import streaming_transfer
from transfer.stop_wait import stop_and_wait_transfer


def create_protocol(protocol_name: str):
    if protocol_name.upper() == "TCP":
        return TCPProtocol()
    elif protocol_name.upper() == "UDP":
        return UDPProtocol()
    else:
        raise ValueError(f"Unsupported protocol: {protocol_name}")


def generate_fast_data(size: int) -> bytes:
    if not hasattr(generate_fast_data, 'buffer') or len(generate_fast_data.buffer) < size:
        pattern = bytes([i % 256 for i in range(1024)])
        generate_fast_data.buffer = pattern * (size // 1024 + 1)
    return generate_fast_data.buffer[:size]

def print_progress(sent: int, total: int):
    percentage = (sent / total) * 100
    print(f"Progress: {percentage:.1f}% ({sent / 1_000_000:.2f}/{total / 1_000_000:.2f} MB)")


def run_client(
        host: str,
        port: int,
        protocol_name: str,
        transfer_method: str,
        data_size_mb: float,
        message_size: int
) -> Dict[str, Any]:
    data_size = int(data_size_mb * 1_000_000)

    protocol = create_protocol(protocol_name)
    if not protocol.initialize() or not protocol.connect(host, port):
        return {"error": "Failed to connect to server"}

    print(f"Connected to server at {host}:{port}, starting transfer...")

    if transfer_method.lower() == "streaming":
        results = streaming_transfer(
            protocol=protocol,
            data_size=data_size,
            message_size=message_size,
            data_generator=generate_fast_data,
            progress_callback=print_progress
        )
    elif transfer_method.lower() == "stop_and_wait":
        results = stop_and_wait_transfer(
            protocol=protocol,
            data_size=data_size,
            message_size=message_size,
            data_generator=generate_fast_data,
            progress_callback=print_progress
        )
    else:
        protocol.close()
        return {"error": f"Unsupported transfer method: {transfer_method}"}

    protocol.close()

    print("\nSummary")
    print(f"Protocol: {protocol_name}")
    print(f"Transfer Method: {transfer_method}")
    print(f"Data Size: {data_size / 1_000_000:.2f} MB")
    print(f"Message Size: {message_size:,} bytes")
    print(f"Total data sent: {results['total_sent']:,} bytes ({results['total_sent'] / 1_000_000:.2f} MB)")
    print(f"Total messages: {results['total_messages']:,}")
    print(f"Duration: {results['duration_sec']:.2f} seconds")
    print(f"Throughput: {results['throughput_mbps']:.2f} Mbps")

    if transfer_method.lower() == "stop_and_wait" and "total_retries" in results:
        print(f"Total retries: {results['total_retries']:,}")

    return results


def main():
    parser = argparse.ArgumentParser(description="Network Benchmark Client")
    parser.add_argument("host", help="Server host address")
    parser.add_argument("--port", type=int, default=5555, help="Server port (default: 5555)")
    parser.add_argument("--protocol", default="TCP", choices=["TCP", "UDP"],
                        help="Transport protocol (default: TCP)")
    parser.add_argument("--method", default="streaming", choices=["streaming", "stop_and_wait"],
                        help="Transfer method (default: streaming)")
    parser.add_argument("--size", type=float, default=500,
                        help="Data size in MB (default: 500)")
    parser.add_argument("--message", type=int, default=8192,
                        help="Message size in bytes (default: 8192)")

    args = parser.parse_args()

    print(f"Starting {args.protocol} client to {args.host}:{args.port}")
    print(f"Transfer method: {args.method}")
    print(f"Data size: {args.size} MB, Message size: {args.message} bytes")

    results = run_client(
        host=args.host,
        port=args.port,
        protocol_name=args.protocol,
        transfer_method=args.method,
        data_size_mb=args.size,
        message_size=args.message
    )

    if "error" not in results:
        os.makedirs("results", exist_ok=True)
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        filename = f"results/client_{args.protocol}_{args.method}_{args.size}MB_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {filename}")


if __name__ == "__main__":
    main()